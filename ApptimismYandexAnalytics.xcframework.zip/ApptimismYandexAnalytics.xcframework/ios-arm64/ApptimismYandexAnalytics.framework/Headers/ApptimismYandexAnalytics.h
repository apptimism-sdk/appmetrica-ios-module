#import <Foundation/Foundation.h>

//! Project version number for ApptimismYandexAnalytics.
FOUNDATION_EXPORT double ApptimismYandexAnalyticsVersionNumber;

//! Project version string for ApptimismYandexAnalytics.
FOUNDATION_EXPORT const unsigned char ApptimismYandexAnalyticsVersionString[];

